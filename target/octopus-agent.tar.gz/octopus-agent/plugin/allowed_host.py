#!/usr/bin/python
# -*- coding: UTF-8 -*-

def job1(a, b):
    print(str(a) + ' ' + str(b))

